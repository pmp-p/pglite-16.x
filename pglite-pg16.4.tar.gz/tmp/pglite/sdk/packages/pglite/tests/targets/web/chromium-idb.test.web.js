import { tests } from './base.js'

tests('chromium', 'idb://base', 'chromium.idb')
