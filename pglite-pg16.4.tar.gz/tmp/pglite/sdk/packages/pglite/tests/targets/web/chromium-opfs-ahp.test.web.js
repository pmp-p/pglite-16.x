import { tests } from './base.js'

tests('chromium', 'opfs-ahp://base', 'chromium.opfs-ahp')
