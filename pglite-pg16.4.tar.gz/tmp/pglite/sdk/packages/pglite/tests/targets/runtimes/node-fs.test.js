import { tests } from './base.js'

tests('node', './pgdata-test', 'node.fs')
