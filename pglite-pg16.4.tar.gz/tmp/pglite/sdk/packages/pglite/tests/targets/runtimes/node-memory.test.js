import { tests } from './base.js'

tests('node', 'memory://', 'node.memory')
