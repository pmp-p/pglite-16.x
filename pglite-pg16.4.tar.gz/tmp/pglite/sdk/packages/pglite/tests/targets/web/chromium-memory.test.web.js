import { tests } from './base.js'

tests('chromium', 'memory://', 'chromium.memory')
