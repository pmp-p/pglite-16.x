import { tests } from './base.js'

tests('firefox', 'memory://', 'firefox.memory')
