import { tests } from './base.js'

tests('firefox', 'opfs-ahp://base', 'firefox.opfs-ahp')
