import { tests } from './base.js'

tests('firefox', 'idb://base', 'firefox.idb')
