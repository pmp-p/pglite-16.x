// Used in tsup.config.ts to replace the `assert` module with a blank file.
