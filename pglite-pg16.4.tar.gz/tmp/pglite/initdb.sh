#!/bin/bash
rm -rf /tmp/pglite/base /tmp/initdb-* /tmp/pglite/wal/*
export TZ=UTC
export PGTZ=UTC
SQL=/tmp/initdb-$$
# TODO: --waldir=/tmp/pglite/wal
> /tmp/initdb.txt

/tmp/pglite/initdb --no-clean --wal-segsize=1 -g C.UTF-8 -U postgres --pwfile=/tmp/pglite/password --pgdata=/tmp/pglite/base

mv /tmp/initdb.boot.txt ${SQL}.boot.sql
mv /tmp/initdb.single.txt ${SQL}.single.sql

if ${CI:-false}
then
    cp -vf $SQL /tmp/pglite/$(md5sum $SQL|cut -c1-32).sql
fi

# --wal-segsize=1  -> -X 1048576

# CKSUM_B -k --data-checksums
# 2024-04-24 05:53:28.121 GMT [42] WARNING:  page verification failed, calculated checksum 5487 but expected 0
# 2024-04-24 05:53:28.121 GMT [42] FATAL:  invalid page in block 0 of relation base/1/1259

CMD="/tmp/pglite/postgres --boot -D /tmp/pglite/base -d 3  -c log_checkpoints=false  -c dynamic_shared_memory_type=posix  -c search_path=pg_catalog  -c exit_on_error=false  -c ignore_invalid_pages=on  -c temp_buffers=8MB -c work_mem=4MB  -c fsync=on -c synchronous_commit=on  -c wal_buffers=4MB -c min_wal_size=80MB  -c shared_buffers=128MB -X 1048576"
echo "$CMD < $SQL.boot.sql"
$CMD < $SQL.boot.sql 2>&1 \
 | grep -v --line-buffered 'bootstrap> boot' \
 | grep -v --line-buffered 'index'

echo "

$(md5sum /tmp/initdb-$$.*.sql)

    boot done
"
