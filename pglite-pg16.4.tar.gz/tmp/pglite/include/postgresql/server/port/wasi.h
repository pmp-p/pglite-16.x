#ifndef I_WASI
#define I_WASI

#define PLATFORM_DEFAULT_SYNC_METHOD    SYNC_METHOD_FDATASYNC

#define EMSCRIPTEN_KEEPALIVE
#define em_callback_func void
#define emscripten_set_main_loop(...)
#define emscripten_force_exit(...)
#define EM_JS(...)

#include "/tmp/pglite/include/wasm_common.h"

static pid_t
fork(void) {
    puts("# 16: fork -1");
    return -1;
}


// TODO: socket here
// ==================================================================

#include <sys/socket.h>
static int
listen(int sockfd, int backlog) {
    return 0;
}

static struct group *_Nullable
getgrnam(const char *_Nullable name) {
    return NULL;
}

static int
getsockname(int sockfd, struct sockaddr *restrict addr, socklen_t *restrict addrlen) {
    return -1;
}

static int
getaddrinfo(const char *restrict node,
                   const char *restrict service,
                   void *restrict hints,
                   void **restrict res) {
    puts("# 45: getaddrinfo");
    return -1;
}
static void
freeaddrinfo(void *res) {
    puts("# 50: freeaddrinfo");
}


// WIP: signal here
// ==================================================================

#define SA_RESTART 0x10000000
#define SIG_BLOCK     0      /* Block signals.  */
#define SIG_UNBLOCK   1      /* Unblock signals.  */
#define SIG_SETMASK   2      /* Set the set of blocked signals.  */

/* Type of a signal handler.  */
typedef void (*__sighandler_t) (int);
# define _SIGSET_NWORDS        (1024 / (8 * sizeof (unsigned long int)))
/*
typedef struct {
    unsigned long int __val[_SIGSET_NWORDS];
} __sigset_t;

typedef struct {
    unsigned long sig[_SIGSET_NWORDS];
} sigset_t;
*/

typedef unsigned char sigset_t;
struct sigaction {
    __sighandler_t sa_handler;
    unsigned long sa_flags;
#ifdef SA_RESTORER
    __sigrestore_t sa_restorer;
#endif
    sigset_t sa_mask;                /* mask last for extensibility */
};

static int
sigemptyset(sigset_t *set) {
    puts("# 74: sigemptyset -1");
    return -1;
}

static int
sigfillset(sigset_t *set) {
    puts("# 80: sigfillset -1");
    return -1;
}
static int
sigaddset(sigset_t *set, int signum) {
    return -1;
}

static int
sigdelset(sigset_t *set, int signum) {
    //puts("# 90: sigdelset -1");
    return -1;
}

static int
sigaction(int signum, const struct sigaction *act, struct sigaction *oldact) {
    puts("# 96: sigaction 0");
    return 0;
}
static int
sigprocmask(int how, const sigset_t *_Nullable restrict set, sigset_t *_Nullable restrict oldset) {
    puts("# 101: sigprocmask 0");
    return 0;
}

#include <setjmp.h>

/*
#include <bits/setjmp.h>

typedef struct __jmp_buf_tag {
    __jmp_buf __jb;
    unsigned long __fl;
    unsigned long __ss[128/sizeof(long)];
} jmp_buf[1];

typedef jmp_buf sigjmp_buf;
*/
static int
sigsetjmp(sigjmp_buf env, int savesigs) {
//    puts("# 120: sigsetjmp");
    return 0;
}

static void
siglongjmp(sigjmp_buf env, int val) {
    puts("# 140: siglongjmp");
}



// WIP :

#include <unistd.h>
static uid_t
getuid(void) {
    return 1000;
}

static int
dup(int fd) {
    puts("# 134: dup");
    return -1;
}
static int
dup2(int old, int new) {
    puts("# 139: dup2");
    return -1;
}
static int
pipe(int fd[2]) {
    puts("# 144: pipe");
    abort();
    return -1;
}

#include <sys/resource.h>
#define RLIMIT_NOFILE 7
#define RLIMIT_STACK 3
#define RLIM_INFINITY ((unsigned long int)(~0UL))

struct rlimit {
    unsigned long   rlim_cur;
    unsigned long   rlim_max;
};
static int
getrlimit(int resource, struct rlimit *rlim) {
    return -1;
}

static int
system_wasi(const char *command) {
    fprintf(stderr, "# 164: system('%s')\n", command);
    return -1;
}

static const char *gai_strerror_msg = "# 168: gai_strerror_msg";
static const char *
gai_strerror(int errcode) {
    return gai_strerror_msg;
}


static int
getrusage(int who, struct rusage *usage) {
    return -1;
}

// WIP: semaphores here
// ==================================================================
#include <sys/sem.h>

static int
semctl(int semid, int semnum, int cmd, ...) {
    return -1;
}

static int
semget(key_t key, int nsems, int semflg) {
    return -1;
}

static int
semop(int semid, struct sembuf *sops, size_t nsops) {
    return -1;
}







static void *
mmap(void *addr, size_t length, int prot, int flags, int fd, off_t offset) {
    puts("# 221: mmap");
    return NULL;

}

static int
munmap(void *addr, size_t length) {
    puts("# 228: munmap");
    return 0;
}

static int
shm_open(const char *name, int oflag, mode_t mode) {
    puts("# 234: shm_open");
    return -1;
}
static int
shm_unlink(const char *name) {
    puts("# 239: shm_unlink");
    return -1;
}

/*

wasm-ld: error: tcop/postgres.o: undefined symbol: pq_recvbuf_fill
wasm-ld: error: utils/error/elog.o: undefined symbol: siglongjmp
wasm-ld: error: utils/error/elog.o: undefined symbol: siglongjmp
wasm-ld: error: ../../src/common/libpgcommon_srv.a(ip_srv.o): undefined symbol: getnameinfo


*/



#endif // I_WASI

