/* src/include/port/win32/netinet/tcp.h */
#ifndef WIN32_NETINET_TCP_H
#define WIN32_NETINET_TCP_H

#include <sys/socket.h>

#endif
