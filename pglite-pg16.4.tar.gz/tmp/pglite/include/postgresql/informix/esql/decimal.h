/* src/interfaces/ecpg/include/decimal.h */

#ifndef _ECPG_DECIMAL_H
#define _ECPG_DECIMAL_H

#include <ecpg_informix.h>

/* source created by ecpg which defines this */
#ifndef _ECPGLIB_H
typedef decimal dec_t;
#endif							/* ndef _ECPGLIB_H */

#endif							/* ndef _ECPG_DECIMAL_H */
