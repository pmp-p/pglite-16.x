#ifndef I_PGDEBUG
#define I_PGDEBUG
#define WASM_USERNAME "postgres"
#define PDEBUG(string)
#define JSDEBUG(string)
#define ADEBUG(string)
#define PGDEBUG 0
#endif
