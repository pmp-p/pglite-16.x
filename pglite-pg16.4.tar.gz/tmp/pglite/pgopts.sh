export CDEBUG="-g3 -O0"
export LDEBUG="-g3 -O0"
export PGDEBUG=""
export PG_DEBUG_HEADER=/tmp/pglite/include/pg_debug.h
export PGOPTS="\
 -c log_checkpoints=false \
 -c dynamic_shared_memory_type=posix \
 -c search_path=pg_catalog \
 -c exit_on_error=false \
 -c ignore_invalid_pages=on \
 -c temp_buffers=8MB -c work_mem=4MB \
 -c fsync=on -c synchronous_commit=on \
 -c wal_buffers=4MB -c min_wal_size=80MB \
 -c shared_buffers=128MB"
export PGSRC=/home/runner/work/pglite-16.x/pglite-16.x/postgresql-16.4
export PGLITE=/home/runner/work/pglite-16.x/pglite-16.x/packages/pglite
