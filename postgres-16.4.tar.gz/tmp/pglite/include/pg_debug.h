#ifndef I_PGDEBUG
#define I_PGDEBUG
#define WASM_USERNAME "postgres"
#define PGDEBUG 1
#define PDEBUG(string) puts(string)
#define JSDEBUG(string) {EM_ASM({ console.log(string); });}
#define ADEBUG(string) { PDEBUG(string); JSDEBUG(string) }
#endif
