#ifndef I_WASI
#define I_WASI

#define COPY_OFF


/* --------------- how to configure those when installed ? ---------------- */

// socket emulation via file, need to go in PGDATA for nodefs mount in web mode
#define PGS_ILOCK "/tmp/pglite/base/.s.PGSQL.5432.lock.in"
#define PGS_IN    "/tmp/pglite/base/.s.PGSQL.5432.in"
#define PGS_OLOCK "/tmp/pglite/base/.s.PGSQL.5432.lock.out"
#define PGS_OUT   "/tmp/pglite/base/.s.PGSQL.5432.out"

// MEMFS ok files

#define IDB_PIPE_FILE "/tmp/initdb.txt"
#define IDB_PIPE_BOOT "/tmp/initdb.boot.txt"
#define IDB_PIPE_SINGLE "/tmp/initdb.single.txt"
#define PG_DEBUG_HEADER <pg_debug.h>


#if defined(PREFIX)
#define em_xstr(s) em_str(s)
#define em_str(s) #s
#   define WASM_PREFIX em_xstr(PREFIX)
#   define PG_MAIN_INCLUDE  em_xstr(PATCH_MAIN)
#   define PG_PLUGIN_INCLUDE  em_xstr(PATCH_PLUGIN
#   undef PG_DEBUG_HEADER
#   define PG_DEBUG_HEADER  em_xstr(PATCH_PG_DEBUG)
#else
#   define WASM_PREFIX "/pgdata"
#   define PG_MAIN_INCLUDE "/pgdata/pg_main.c"
#   define PG_PLUGIN_INCLUDE "/pgdata/pg_plugin.h"
#endif

// #include PG_DEBUG_HEADER
#include "/tmp/pglite/include/pg_debug.h"



#define PGDLLIMPORT
#define PG_FORCE_DISABLE_INLINE














#define PLATFORM_DEFAULT_WAL_SYNC_METHOD	WAL_SYNC_METHOD_FDATASYNC
#define PLATFORM_DEFAULT_SYNC_METHOD    SYNC_METHOD_FDATASYNC



// force the name used with --single
#define WASM_USERNAME "postgres"

#define WASM_PGOPTS \
        "-c", "log_checkpoints=false",\
        "-c", "search_path=pg_catalog",\
        "-c", "exit_on_error=true",\
        "-c", "ignore_invalid_pages=on",\
        "-c", "temp_buffers=8MB",\
        "-c", "work_mem=4MB",\
        "-c", "fsync=on",\
        "-c", "synchronous_commit=on",\
        "-c", "wal_buffers=4MB",\
        "-c", "min_wal_size=80MB",\
        "-c", "shared_buffers=128MB"




// we want client and server in the same lib for now.
#if defined(PG_INITDB) && defined(PG_MAIN)
extern const char *progname;
#endif


#define proc_exit(arg) pg_proc_exit(arg)



static pid_t
fork(void) {
    puts("fork -1");
    return -1;
}


// TODO: socket here
// ==================================================================

#include <sys/socket.h>
static int
listen(int sockfd, int backlog) {
    return 0;
}

static struct group *_Nullable
getgrnam(const char *_Nullable name) {
    return NULL;
}

static int
getsockname(int sockfd, struct sockaddr *restrict addr, socklen_t *restrict addrlen) {
    return -1;
}







// WIP: signal here
// ==================================================================

#define SA_RESTART 0x10000000
#define SIG_BLOCK     0      /* Block signals.  */
#define SIG_UNBLOCK   1      /* Unblock signals.  */
#define SIG_SETMASK   2      /* Set the set of blocked signals.  */

/* Type of a signal handler.  */
typedef void (*__sighandler_t) (int);
# define _SIGSET_NWORDS        (1024 / (8 * sizeof (unsigned long int)))
/*
typedef struct {
    unsigned long int __val[_SIGSET_NWORDS];
} __sigset_t;

typedef struct {
    unsigned long sig[_SIGSET_NWORDS];
} sigset_t;
*/

typedef unsigned char sigset_t;
struct sigaction {
    __sighandler_t sa_handler;
    unsigned long sa_flags;
#ifdef SA_RESTORER
    __sigrestore_t sa_restorer;
#endif
    sigset_t sa_mask;                /* mask last for extensibility */
};

static int
sigemptyset(sigset_t *set) {
    puts("sigemptyset -1");
    return -1;
}

static int
sigfillset(sigset_t *set) {
    puts("sigfillset -1");
    return -1;
}
static int
sigdelset(sigset_t *set, int signum) {
    puts("sigdelset -1");
    return -1;
}

static int
sigaction(int signum, const struct sigaction *act, struct sigaction *oldact) {
    puts("sigaction 0");
    return 0;
}
static int
sigprocmask(int how, const sigset_t *_Nullable restrict set, sigset_t *_Nullable restrict oldset) {
    puts("sigprocmask 0");
    return 0;
}


#include <unistd.h>
static uid_t
getuid(void) {
    return 1000;
}

#include <sys/resource.h>
#define RLIMIT_NOFILE 7


#endif // I_WASI

